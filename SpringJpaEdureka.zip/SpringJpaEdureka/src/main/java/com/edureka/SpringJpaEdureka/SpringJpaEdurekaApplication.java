package com.edureka.SpringJpaEdureka;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringJpaEdurekaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringJpaEdurekaApplication.class, args);
	}

}
